package com.example.lf;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
         final EditText x = findViewById(R.id.editTextTextPersonName3);
        final EditText y = findViewById(R.id.editTextTextPersonName);
        Button s = findViewById(R.id.button);
        Button r = findViewById(R.id.button2);
        Button l = findViewById(R.id.button3);
        s.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int b = Integer.parseInt(x.getText().toString());
                int a = Integer.parseInt(y.getText().toString());
                int sum = b+a;
                Toast.makeText(MainActivity.this, sum+"", Toast.LENGTH_SHORT).show();

            }
        });
        r.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int b = Integer.parseInt(x.getText().toString());
                int a = Integer.parseInt(y.getText().toString());
                int sm = b*a;
                Toast.makeText(MainActivity.this, sm+"", Toast.LENGTH_SHORT).show();

            }
        });
        l.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int b = Integer.parseInt(x.getText().toString());
                int a = Integer.parseInt(y.getText().toString());
                int m = b /a;
                Toast.makeText(MainActivity.this, m+"", Toast.LENGTH_SHORT).show();

            }
        });

        }
    }
